/**
 * Created by Tungnt on 10/16/2015.
 */
var products = []; // Khai bao 1 mang rong.

products.push(
    {
        id: 1,
        imgSrc: 'data/2.png',
        name: 'NOKIA 1100',
        price: '12'
    }
);
products.push({id: 2, imgSrc: 'data/2.png', name: 'Nokia', price: '13'});
products.push({id: 3, imgSrc: 'data/3.png', name: 'Product 3', price: '15'});

products.push({id: 4, imgSrc: 'data/2.png', name: 'Product 4', price: '20'});
products.push({id: 5, imgSrc: 'data/2.png', name: 'Nokia 3', price: '21'});
products.push({id: 6, imgSrc: 'data/3.png', name: 'Product 6', price: '22'});


package service;

public interface ApplicationRunningInterface {
	public void run();
}

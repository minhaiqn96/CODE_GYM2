package day14;

public class Music extends Entertainment{

	public Music(String name) {
		this.setName(name);
		
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.name.toString();
	}
}

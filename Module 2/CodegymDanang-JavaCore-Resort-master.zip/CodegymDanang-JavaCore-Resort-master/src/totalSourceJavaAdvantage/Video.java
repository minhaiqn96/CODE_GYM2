package totalSourceJavaAdvantage;

public class Video extends Entertainment{

	public Video(String name) {
		this.setName(name);
	}
	@Override
	public String toString() {
		return super.name.toString();
	}

}

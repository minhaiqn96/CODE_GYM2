package totalSourceJavaAdvantage;

import java.util.Date;

public class Tour {

	private String nameTour;
	private float priceTour;
	private Date startTour;
	private Date endTour;
	private String tourInformation;
	
	public String getNameTour() {
		return nameTour;
	}
	public void setNameTour(String nameTour) {
		this.nameTour = nameTour;
	}
	public float getPriceTour() {
		return priceTour;
	}
	public void setPriceTour(float priceTour) {
		this.priceTour = priceTour;
	}
	public Date getStartTour() {
		return startTour;
	}
	public void setStartTour(Date startTour) {
		this.startTour = startTour;
	}
	public Date getEndTour() {
		return endTour;
	}
	public void setEndTour(Date endTour) {
		this.endTour = endTour;
	}
	public String getTourInformation() {
		return tourInformation;
	}
	public void setTourInformation(String tourInformation) {
		this.tourInformation = tourInformation;
	}
	
	
	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}

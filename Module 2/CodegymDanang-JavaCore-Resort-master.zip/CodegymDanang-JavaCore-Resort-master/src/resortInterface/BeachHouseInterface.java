package resortInterface;

public interface BeachHouseInterface {
	public static int NUMBER_BED = 4;
	public static int PRICE_ONEDATE = 5;
}	

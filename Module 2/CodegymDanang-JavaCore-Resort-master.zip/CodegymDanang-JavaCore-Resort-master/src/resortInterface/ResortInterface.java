package resortInterface;

public interface ResortInterface {
	public static int NUMBER_VILLA = 5;
	public static int NUMBER_BEACHHOUSE = 2;
	public static int NUMBER_SWIMMINGPOOL = 1;
}

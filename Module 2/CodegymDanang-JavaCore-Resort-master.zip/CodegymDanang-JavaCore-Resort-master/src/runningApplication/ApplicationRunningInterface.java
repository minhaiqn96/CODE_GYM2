package runningApplication;

public interface ApplicationRunningInterface {
	public void run();
}

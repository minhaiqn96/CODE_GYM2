package day06;

public class Book extends Entertainment{

	public Book(String name) {
		this.setName(name);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.name.toString();
	}

}

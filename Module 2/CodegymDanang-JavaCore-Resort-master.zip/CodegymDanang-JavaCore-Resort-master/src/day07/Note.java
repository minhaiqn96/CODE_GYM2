package day07;

public class Note {
	//check Java convention and Access Modifier.
	

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-house',
  templateUrl: './feedback-house.component.html',
  styleUrls: ['./feedback-house.component.css']
})
export class FeedbackHouseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
